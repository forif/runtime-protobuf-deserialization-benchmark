require("../lib/path/tests");
