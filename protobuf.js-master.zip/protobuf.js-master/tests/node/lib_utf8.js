require("../../lib/utf8/tests"); // requires fs to load the test file
